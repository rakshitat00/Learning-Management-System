<footer>
	<center>
		<p>&copy; GUNI e-Learning Management System Copyright 2021</p>
	</center>
	<div class="pull-right">
			<p>Programmed by: Samit Dhawal(19162121049)</p>
	</div> 
</footer>


