<div class="row-fluid">

<div class="span12">

</div>	
                            
    </div>
    <div class="row-fluid">

<div class="span4">
<img class="index_logo" src="LogoICT.png">
</div>	
<div class="span8">

<div class="title">
    <h2>
    <p class="chmsc">An e-learning initiative by:</p>
    </h2>
    <h3>
    <p class="chmsc">Ganpat University, ICT Campus,<br>
    Department of Big Data Analytics.</p>
    </h3>
	
</div>

</div>							
    </div>

<div class="row-fluid">

<div class="span12">
<br>
        <div class="motto">
                        <p>GUNI CAMPUS, Mehsana:</p>
                        <p>Ganpat Vidyanagar, Mehsana-Gozaria Highway,
                        <p>PO - 384012,North Gujarat, INDIA </p>
                        <p>Email:info@ganpatuniversity.ac.in</p>
                        <p>Tele Fax : +91-2762-226000, 286080 Toll Free No : 1800 233 12345</p>
                        
        </div>		
</div>		
</div>