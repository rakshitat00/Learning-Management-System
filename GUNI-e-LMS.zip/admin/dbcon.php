<?php
$servername = "127.0.0.1:3307";
$username = "root";
$password = "";
$dbname = "se_batch54_lms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
