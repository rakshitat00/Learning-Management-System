<div class="pull-right">
		<footer>
           <p>Programmed by: Rakshita Tripathi, BDA, ICT-SEM V</p>
        <footer>
</div>